<?php

class Declaration
{
    /**
     * Récupère le chiffre d'affaires groupé par type de soin pour un mois donné
     * @param int $mois (1-12)
     * @param int $annee (ex: 2025)
     * @return array [['type' => 'Bain Brush', 'total' => 450.00], ...]
     */
    public static function getCAParType(int $mois, int $annee): array
    {
        $pdo = Database::getConnection();

        $sql = "SELECT type_soin, prix
                FROM Prestations
                WHERE MONTH(date_soin) = :mois
                  AND YEAR(date_soin)  = :annee
                ORDER BY date_soin";

        $stmt = $pdo->prepare($sql);
        $stmt->execute(['mois' => $mois, 'annee' => $annee]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Décomposer chaque prestation (une ligne peut contenir "Bain Brush, Tonte, Vente Jouet (8.50€)")
        $totaux = [];
        foreach ($rows as $row) {
            $types = explode(', ', $row['type_soin'] ?? '');
            $nbTypes = count($types);
            // Séparer les ventes (qui ont leur propre prix) des soins
            $ventes = [];
            $soins = [];
            foreach ($types as $t) {
                $t = trim($t);
                if ($t === '') continue;
                if (strpos($t, 'Vente') === 0) {
                    // Extraire le prix de la vente si présent ex: "Vente Jouet (8.50€)"
                    if (preg_match('/\((\d+[\.,]\d+)€?\)/', $t, $m)) {
                        $prixVente = (float)str_replace(',', '.', $m[1]);
                        // Nettoyer le label
                        $label = preg_replace('/\s*\(\d+[\.,]\d+€?\)/', '', $t);
                        $ventes[] = ['label' => trim($label), 'prix' => $prixVente];
                    } else {
                        $soins[] = $t;
                    }
                } else {
                    $soins[] = $t;
                }
            }

            // Répartir le prix de la prestation (hors ventes) entre les soins
            $prixTotal = (float)$row['prix'];
            $prixVentesTotal = 0;
            foreach ($ventes as $v) {
                $prixVentesTotal += $v['prix'];
                if (!isset($totaux[$v['label']])) $totaux[$v['label']] = 0;
                $totaux[$v['label']] += $v['prix'];
            }

            $prixSoins = $prixTotal - $prixVentesTotal;
            $nbSoins = count($soins);
            if ($nbSoins > 0 && $prixSoins > 0) {
                $prixParSoin = $prixSoins / $nbSoins;
                foreach ($soins as $s) {
                    if (!isset($totaux[$s])) $totaux[$s] = 0;
                    $totaux[$s] += $prixParSoin;
                }
            }
        }

        // Regrouper en 2 grandes catégories : Toilettage et Ventes
        $totalToilettage = 0;
        $totalVentes = 0;
        foreach ($totaux as $type => $total) {
            if (strpos($type, 'Vente') === 0) {
                $totalVentes += $total;
            } else {
                $totalToilettage += $total;
            }
        }

        $result = [];
        if ($totalToilettage > 0) {
            $result[] = ['type' => '✂️ Toilettage', 'total' => round($totalToilettage, 2)];
        }
        if ($totalVentes > 0) {
            $result[] = ['type' => '🛒 Ventes', 'total' => round($totalVentes, 2)];
        }

        return $result;
    }

    /**
     * Récupère le CA total pour un mois donné
     */
    public static function getCATotalMois(int $mois, int $annee): float
    {
        $pdo = Database::getConnection();

        $sql = "SELECT COALESCE(SUM(prix), 0) as total
                FROM Prestations
                WHERE MONTH(date_soin) = :mois
                  AND YEAR(date_soin)  = :annee";

        $stmt = $pdo->prepare($sql);
        $stmt->execute(['mois' => $mois, 'annee' => $annee]);
        return (float)$stmt->fetchColumn();
    }

    /**
     * Récupère le nombre de prestations pour un mois donné
     */
    public static function getNbPrestationsMois(int $mois, int $annee): int
    {
        $pdo = Database::getConnection();

        $sql = "SELECT COUNT(*) FROM Prestations
                WHERE MONTH(date_soin) = :mois
                  AND YEAR(date_soin)  = :annee";

        $stmt = $pdo->prepare($sql);
        $stmt->execute(['mois' => $mois, 'annee' => $annee]);
        return (int)$stmt->fetchColumn();
    }
}
