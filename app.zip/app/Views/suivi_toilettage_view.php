
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suivi - <?= htmlspecialchars($animal['nom_animal'] ?? 'Animal'); ?></title>

    <!-- ✅ CSS : chemin ABSOLU (sinon cassé sur /animals/33/tracking) -->
    <link rel="stylesheet" href="<?= url('assets/style.css') ?>">


    <style>
        .prestation-selector { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 8px; }
        .prestation-selector input[type="checkbox"], .paiement-selector input[type="radio"] { display: none; }
        .prestation-label {
            padding: 8px 16px; background: #f0f0f0; border: 2px solid #ddd;
            border-radius: 20px; cursor: pointer; font-size: 0.9em; transition: all 0.3s ease;
            color: #555;
        }
        .prestation-selector input[type="checkbox"]:checked + .prestation-label {
            background-color: var(--vert-moyen); border-color: var(--vert-fonce); color: white;
        }
        /* Mode de paiement */
        .paiement-selector { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 8px; }
        .paiement-label {
            padding: 10px 20px; background: #f8fafc; border: 2px solid #e2e8f0;
            border-radius: 12px; cursor: pointer; font-size: 0.9em; transition: all 0.3s ease;
            color: #475569; font-weight: 600; display: inline-flex; align-items: center; gap: 6px;
        }
        .paiement-label:hover { border-color: #3b82f6; background: #eff6ff; }
        .paiement-selector input[type="radio"]:checked + .paiement-label {
            background: #2563eb; border-color: #2563eb; color: white;
        }
        .tag-soin {
            background: #e8f5e9; color: #2e7d32; padding: 4px 10px; border-radius: 6px;
            font-size: 0.8em; font-weight: 600; border: 1px solid #c8e6c9; margin-right: 5px;
        }
        .tag-vente {
            background: #ede9fe; color: #6d28d9; padding: 4px 10px; border-radius: 6px;
            font-size: 0.8em; font-weight: 600; border: 1px solid #ddd6fe; margin-right: 5px;
        }
        .info-bandeau {
            background: #fff; padding: 15px; border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 20px;
            display: flex; gap: 20px; flex-wrap: wrap; border: 1px solid #eee;
        }
        .info-box { flex: 1; min-width: 120px; }
        .info-box strong { display: block; color: #7f8c8d; font-size: 0.75rem; text-transform: uppercase; }
        .btn-download-pdf {
            text-decoration: none;
            background: #e8f5e9;
            color: #2e7d32;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.85em;
            font-weight: bold;
            border: 1px solid #c8e6c9;
        }
        .btn-download-pdf:hover { background: #c8e6c9; }
        .btn-generate-invoice {
            text-decoration: none;
            background: #fff3cd;
            color: #856404;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.85em;
            font-weight: bold;
            border: 1px solid #ffeaa7;
        }
        .btn-generate-invoice:hover { background: #ffeaa7; }

        /* === Modal Vente === */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.5); z-index: 9999; justify-content: center; align-items: center;
        }
        .modal-overlay.active { display: flex; }
        .modal-content {
            background: white; border-radius: 16px; padding: 30px; width: 420px; max-width: 90%;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2); position: relative; animation: modalIn 0.3s ease;
        }
        @keyframes modalIn { from { opacity: 0; transform: scale(0.9) translateY(20px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        .modal-close {
            position: absolute; top: 12px; right: 15px; background: none; border: none;
            font-size: 1.5rem; cursor: pointer; color: #94a3b8; transition: color 0.2s;
        }
        .modal-close:hover { color: #333; }
        .modal-title { margin: 0 0 20px 0; color: #1e293b; font-size: 1.2rem; }
        .vente-type-selector { display: flex; gap: 12px; margin-bottom: 20px; }
        .vente-type-btn {
            flex: 1; padding: 15px; border: 2px solid #e2e8f0; border-radius: 12px;
            background: #f8fafc; cursor: pointer; text-align: center; transition: all 0.3s ease;
            font-size: 0.95rem; color: #475569;
        }
        .vente-type-btn:hover { border-color: #a78bfa; background: #f5f3ff; }
        .vente-type-btn.selected { border-color: #7c3aed; background: #ede9fe; color: #7c3aed; font-weight: bold; }
        .vente-type-btn .vente-icon { font-size: 1.8rem; display: block; margin-bottom: 6px; }
        .btn-vente-submit {
            background: #7c3aed; color: white; border: none; padding: 12px 30px;
            border-radius: 10px; font-weight: bold; cursor: pointer; width: 100%;
            font-size: 1rem; transition: all 0.3s ease; margin-top: 10px;
        }
        .btn-vente-submit:hover { background: #6d28d9; transform: translateY(-1px); }
        .btn-vente-submit:disabled { background: #cbd5e1; cursor: not-allowed; transform: none; }

        /* ============================
           RESPONSIVE MOBILE
           ============================ */
        @media (max-width: 768px) {
            body { padding: 10px !important; }
            .container-large { padding: 10px !important; }

            .header-flex {
                flex-direction: column !important;
                align-items: flex-start !important;
                gap: 10px;
            }
            .header-flex h2 { font-size: 1.1rem; }

            .info-bandeau {
                flex-direction: column;
                gap: 10px;
                padding: 12px;
            }
            .info-box { min-width: auto; }

            /* Formulaire nouvelle visite */
            #nouvelle-visite { padding: 15px !important; }

            .prestation-selector { gap: 6px; }
            .prestation-label { padding: 6px 12px; font-size: 0.8em; }

            .paiement-selector { gap: 6px; }
            .paiement-label { padding: 8px 14px; font-size: 0.8em; }

            /* Prix + Paiement en colonne sur mobile */
            #nouvelle-visite div[style*="grid-template-columns: 1fr 1fr"] {
                display: flex !important;
                flex-direction: column !important;
                gap: 15px !important;
            }

            /* Tableau historique en cartes */
            table { border-spacing: 0; }
            table thead { display: none; }
            table, table tbody, table tr, table td { display: block; width: 100%; }
            table tr {
                margin-bottom: 12px;
                border: 1px solid #f1f5f9;
                border-radius: 12px;
                overflow: hidden;
                background: white;
                box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            }
            table td {
                padding: 8px 15px !important;
                border-bottom: 1px solid #f8f9fa !important;
                text-align: left !important;
            }
            table td:before {
                content: attr(data-label);
                font-weight: 700;
                font-size: 0.7rem;
                text-transform: uppercase;
                color: #94a3b8;
                display: block;
                margin-bottom: 3px;
            }
            table td:last-child { border-bottom: none !important; }

            .tag-soin, .tag-vente { font-size: 0.72em; padding: 3px 8px; margin-bottom: 3px; display: inline-block; }

            .btn-download-pdf, .btn-generate-invoice { font-size: 0.78em; padding: 4px 8px; }

            /* Modal vente */
            .modal-content { width: 95% !important; padding: 20px !important; }
            .vente-type-selector { flex-direction: column; gap: 8px; }
        }

        @media (max-width: 480px) {
            .header-flex h2 { font-size: 1rem; }
            .info-bandeau { font-size: 0.85rem; }
        }
    </style>
</head>
<body>

<?php if (isset($_GET['success']) && (int)$_GET['success'] === 1): ?>
    <div id="success-banner" style="background: #d4edda; color: #155724; padding: 20px; border: 1px solid #c3e6cb; border-radius: 8px; margin: 20px auto; max-width: 800px; text-align: center; font-family: sans-serif;">
        <h2 style="margin: 0 0 10px 0;">✅ Encaissement validé !</h2>
        <p style="margin: 5px 0;">La facture Factur-X a été générée et transmise à N2F.</p>

        <?php if (!empty($download_link)): ?>
            <p style="font-size: 0.9em; color: #666;">
                Le téléchargement de la facture va démarrer... <br>
                <small>Si rien ne se passe, <a href="<?= htmlspecialchars($download_link) ?>" download style="color: #155724; text-decoration: underline;">cliquez ici pour la récupérer</a>.</small>
            </p>

            <script>
                window.addEventListener('load', function() {
                    setTimeout(function() {
                        const link = document.createElement('a');
                        link.href = <?= json_encode($download_link) ?>;
                        link.download = <?= json_encode($nomFichierPDF ?? 'facture.pdf') ?>;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }, 500);
                });
            </script>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="container-large">
    <div class="header-flex" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
        <div>
            <h2 style="margin-bottom: 5px;">🧼 Dossier de <?= htmlspecialchars($animal['nom_animal'] ?? ''); ?></h2>
            <span style="color: #7f8c8d;">
                Propriétaire : <strong><?= htmlspecialchars(($animal['prenom'] ?? '') . ' ' . ($animal['nom'] ?? '')); ?></strong>
            </span>
        </div>

        <!-- ✅ Retour : utiliser une route -->
        <a href="<?= route('clients.index') ?>" class="btn-edit" style="text-decoration: none; background: #eee; color: #333;">← Retour</a>
    </div>

    <div class="info-bandeau">
        <div class="info-box">
            <strong>Animal / Race</strong>
            🐾 <?= htmlspecialchars($animal['espece'] ?? ''); ?> (<?= htmlspecialchars($animal['race'] ?? 'Inconnue'); ?>)
        </div>
        <div class="info-box">
            <strong>Poids</strong>
            ⚖️ <?= !empty($animal['poids']) ? htmlspecialchars($animal['poids']).' kg' : '---'; ?>
        </div>
        <div class="info-box">
            <strong>Sexe</strong>
            <?php
                $sexe = $animal['sexe'] ?? '';
                if ($sexe === 'M') {
                    echo '<span style="color: #2980b9; font-weight: bold;">♂ Mâle</span>';
                } elseif ($sexe === 'F') {
                    echo '<span style="color: #e84393; font-weight: bold;">♀ Femelle</span>';
                } else {
                    echo '<span style="color: #7f8c8d;">---</span>';
                }
            ?>
        </div>
        <div class="info-box">
            <strong>Stérilisé</strong>
            <?php if(($animal['steril'] ?? 0) == 1): ?>
                <span style="color: #2e7d32; font-weight: bold;">✅ OUI</span>
            <?php else: ?>
                <span style="color: #e67e22; font-weight: bold;">❌ NON</span>
            <?php endif; ?>
        </div>
        <div class="info-box">
            <strong>Date de naissance</strong>
            <?php if (!empty($animal['date_naissance'])): ?>
                <?php
                    $dateNaiss = new DateTime($animal['date_naissance']);
                    $aujourdHui = new DateTime();
                    $diff = $dateNaiss->diff($aujourdHui);
                    if ($diff->y > 0) {
                        $age = $diff->y . ' an' . ($diff->y > 1 ? 's' : '');
                        if ($diff->m > 0) $age .= ' ' . $diff->m . ' mois';
                    } else {
                        $age = $diff->m . ' mois';
                    }
                ?>
                🎂 <?= $dateNaiss->format('d/m/Y') ?> <span style="color: #2e7d32; font-weight: bold;">(<?= $age ?>)</span>
            <?php else: ?>
                <span style="color: #7f8c8d;">---</span>
            <?php endif; ?>
        </div>
        <div class="info-box">
            <strong>Téléphone</strong>
            📞 <?= !empty($animal['telephone']) ? htmlspecialchars(wordwrap($animal['telephone'], 2, ' ', true)) : '---'; ?>
        </div>
    </div>

    <h3 id="historique-soins" style="margin-bottom: 15px;">Historique des soins</h3>
    <table style="background: white; border-radius: 12px; overflow: hidden; border-collapse: separate; border-spacing: 0; width: 100%;">
        <thead style="background: #f8f9fa;">
            <tr>
                <th style="padding: 15px; text-align: left;">Date</th>
                <th style="text-align: left;">Prestations</th>
                <th style="text-align: left;">Observations</th>
                <th style="text-align: left;">Prix</th>
                <th style="text-align: center;">Paiement</th>
                <th style="text-align: center;">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if(empty($historique)): ?>
            <tr><td colspan="6" style="padding: 20px; text-align: center;">Aucun soin enregistré.</td></tr>
        <?php else: ?>
            <?php foreach ($historique as $soin): ?>
                <tr style="border-bottom: 1px solid #eee;">
                    <td data-label="Date" style="padding: 15px;"><strong><?= date('d/m/Y', strtotime($soin['date_soin'])); ?></strong></td>
                    <td data-label="Prestations">
                        <?php
                        $tags = explode(", ", $soin['type_soin'] ?? '');
                        foreach($tags as $tag){
                            $tag = trim($tag);
                            if($tag === '') continue;
                            if(strpos($tag, 'Vente') === 0) {
                                echo "<span class='tag-vente'>🛒 " . htmlspecialchars($tag) . "</span>";
                            } else {
                                echo "<span class='tag-soin'>" . htmlspecialchars($tag) . "</span>";
                            }
                        }
                        ?>
                    </td>
                    <td data-label="Notes" style="color: #7f8c8d; font-size: 0.9em;"><?= htmlspecialchars($soin['notes'] ?? '-'); ?></td>
                    <td data-label="Prix" style="white-space: nowrap;"><span style="font-weight: bold; color: #2e7d32; white-space: nowrap;"><?= number_format((float)$soin['prix'], 2, ',', ' '); ?>&nbsp;€</span></td>
                    <td data-label="Paiement" style="text-align: center;">
                        <?php
                            $mp = $soin['mode_paiement'] ?? '';
                            if ($mp === 'CB') {
                                echo '<span style="background:#dbeafe; color:#1e40af; padding:4px 10px; border-radius:6px; font-size:0.8em; font-weight:700; display:inline-flex; align-items:center; gap:4px; white-space:nowrap;">💳 CB</span>';
                            } elseif ($mp === 'Chèque') {
                                echo '<span style="background:#fef3c7; color:#92400e; padding:4px 10px; border-radius:6px; font-size:0.8em; font-weight:700; display:inline-flex; align-items:center; gap:4px; white-space:nowrap;">📝 Chèque</span>';
                            } elseif ($mp === 'Espèces') {
                                echo '<span style="background:#d1fae5; color:#065f46; padding:4px 10px; border-radius:6px; font-size:0.8em; font-weight:700; display:inline-flex; align-items:center; gap:4px; white-space:nowrap;">💶 Espèces</span>';
                            } else {
                                echo '<span style="color:#94a3b8; font-size:0.8em;">—</span>';
                            }
                        ?>
                    </td>
                   <td data-label="Actions" style="text-align: center; white-space: nowrap;">
  <?php
    $idPrest = (int)($soin['id_prestation'] ?? 0);
    $annee   = date('Y', strtotime($soin['date_soin'] ?? 'now'));

    // ✅ Nom du fichier PDF
    $nomFichierPDF = "Facture_SweetyDog_{$annee}-{$idPrest}.pdf";
    
    // ✅ Chemin disque (pour vérifier si le fichier existe)
    $cheminFacture = __DIR__ . '/../../factures/' . $nomFichierPDF;
    
    // 🔒 URL SÉCURISÉE : passe par le contrôleur au lieu d'un accès direct
    $pdf_url = route('invoices.download', ['id' => $idPrest]);
  ?>

  <?php if ($idPrest > 0 && file_exists($cheminFacture)) : ?>
    <!-- 🔒 Bouton vert pour télécharger via route sécurisée -->
    <a href="<?= htmlspecialchars($pdf_url) ?>"
       target="_blank"
       class="btn-download-pdf"
       title="Ouvrir la facture PDF">
      📄 Facture
    </a>
  <?php else : ?>
    <!-- ⚙️ Bouton pour générer la facture si elle n'existe pas -->
    <a href="<?= route('invoices.generate', ['id' => $idPrest]) ?>" 
       class="btn-generate-invoice"
       title="Générer la facture">
      ⚙️ Générer
    </a>
  <?php endif; ?>

  <span title="Prestation verrouillée"
        style="margin-left: 10px; cursor: help; filter: grayscale(100%); opacity: 0.5;">🔒</span>
</td>


                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- ===== MODAL VENTE ===== -->
<div class="modal-overlay" id="modal-vente">
    <div class="modal-content">
        <button class="modal-close" id="btn-close-vente">&times;</button>
        <h3 class="modal-title">🛒 Ajouter une vente</h3>

        <p style="font-weight: 600; color: #475569; margin-bottom: 10px;">Type de vente</p>
        <div class="vente-type-selector">
            <div class="vente-type-btn" data-type="Jouet">
                <span class="vente-icon">🧸</span>
                Jouet
            </div>
            <div class="vente-type-btn" data-type="Cosmétique">
                <span class="vente-icon">🧴</span>
                Cosmétique
            </div>
        </div>

        <div style="margin-bottom: 15px;">
            <label style="font-weight: 600; color: #475569; font-size: 0.9rem;">Détail du produit (optionnel)</label>
            <input type="text" id="vente-detail" placeholder="Ex: Shampoing bio, Balle en caoutchouc..."
                   style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 10px; box-sizing: border-box; margin-top: 5px; background: #f8fafc; font-size: 0.95rem;">
        </div>

        <div style="margin-bottom: 15px;">
            <label style="font-weight: 600; color: #475569; font-size: 0.9rem;">Prix de la vente (€)</label>
            <input type="number" step="0.01" id="vente-prix" placeholder="Ex: 12.50"
                   style="width: 100%; padding: 12px; border: 1px solid #e2e8f0; border-radius: 10px; box-sizing: border-box; margin-top: 5px; background: #f8fafc; font-size: 1.1rem; font-weight: bold; text-align: center;">
        </div>

        <button type="button" class="btn-vente-submit" id="btn-vente-ajouter" disabled>
            ✅ Ajouter au panier
        </button>
    </div>
</div>

<script>
(function() {
    var modal = document.getElementById('modal-vente');
    var btnOpen = document.getElementById('btn-open-vente');
    var btnClose = document.getElementById('btn-close-vente');
    var detailInput = document.getElementById('vente-detail');
    var prixInput = document.getElementById('vente-prix');
    var btnAjouter = document.getElementById('btn-vente-ajouter');
    var typeBtns = document.querySelectorAll('.vente-type-btn');
    var ventesContainer = document.getElementById('ventes-ajoutees');
    var hiddenContainer = document.getElementById('ventes-hidden-inputs');
    var selectedType = '';
    var venteCount = 0;

    // Ouvrir la modale
    btnOpen.addEventListener('click', function() {
        // Reset les champs
        selectedType = '';
        detailInput.value = '';
        prixInput.value = '';
        btnAjouter.disabled = true;
        typeBtns.forEach(function(b) { b.classList.remove('selected'); });
        modal.classList.add('active');
    });

    // Fermer la modale
    btnClose.addEventListener('click', function() {
        modal.classList.remove('active');
    });
    modal.addEventListener('click', function(e) {
        if (e.target === modal) modal.classList.remove('active');
    });

    // Sélection du type de vente
    typeBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            typeBtns.forEach(function(b) { b.classList.remove('selected'); });
            btn.classList.add('selected');
            selectedType = btn.getAttribute('data-type');
            checkForm();
        });
    });

    prixInput.addEventListener('input', checkForm);

    function checkForm() {
        var prixOk = parseFloat(prixInput.value) > 0;
        var typeOk = selectedType !== '';
        btnAjouter.disabled = !(prixOk && typeOk);
    }

    // Ajouter la vente au formulaire principal
    btnAjouter.addEventListener('click', function() {
        var type = selectedType;
        var detail = detailInput.value.trim();
        var prix = parseFloat(prixInput.value);
        var venteId = 'vente-' + (++venteCount);
        var label = 'Vente ' + type + (detail ? ' (' + detail + ')' : '') + ' — ' + prix.toFixed(2) + ' €';

        // Créer le input hidden dans le formulaire principal
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'type_soin[]';
        input.value = 'Vente ' + type + (detail ? ' : ' + detail : '') + ' (' + prix.toFixed(2) + '€)';
        input.id = venteId;
        hiddenContainer.appendChild(input);

        // Aussi stocker le prix de la vente pour l'ajouter au total
        var inputPrix = document.createElement('input');
        inputPrix.type = 'hidden';
        inputPrix.name = 'vente_prix[]';
        inputPrix.value = prix.toFixed(2);
        inputPrix.id = venteId + '-prix';
        hiddenContainer.appendChild(inputPrix);

        // Afficher le badge visuel
        var badge = document.createElement('span');
        badge.id = venteId + '-badge';
        badge.style.cssText = 'display:inline-flex; align-items:center; gap:6px; background:#ede9fe; color:#7c3aed; padding:6px 14px; border-radius:20px; font-size:0.85em; font-weight:600; border:1px solid #ddd6fe;';
        badge.innerHTML = '🛒 ' + escapeHtml(label) + ' <button type="button" style="background:none; border:none; color:#a78bfa; cursor:pointer; font-size:1.1em; padding:0 0 0 4px;" data-vente-id="' + venteId + '">&times;</button>';
        ventesContainer.appendChild(badge);

        // Bouton supprimer le badge
        badge.querySelector('button').addEventListener('click', function() {
            document.getElementById(venteId).remove();
            document.getElementById(venteId + '-prix').remove();
            badge.remove();
        });

        // Fermer la modale
        modal.classList.remove('active');
    });

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
})();
</script>

</body>
</html>
