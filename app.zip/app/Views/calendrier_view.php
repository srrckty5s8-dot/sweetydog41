<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda | SweetyDog</title>
    <link rel="stylesheet" href="<?= htmlspecialchars(url('assets/style.css')) ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>
    <style>
        body { background: #f4f7f6; font-family: 'Segoe UI', sans-serif; color: #333; }

        .container-large { max-width: 1100px; padding: 25px; margin: 0 auto; }

        /* TOP BAR (identique aux autres pages) */
        .top-bar {
            display: flex; justify-content: space-between; align-items: center;
            gap: 20px; margin-bottom: 25px;
        }
        .brand h2 { margin: 0; color: var(--vert-fonce); }
        .top-nav { display: flex; gap: 16px; align-items: center; flex-wrap: wrap; }
        .top-nav a { text-decoration: none; color: #666; font-size: .9rem; font-weight: 600; }
        .top-nav a:hover { color: var(--vert-fonce); }
        .top-nav a.active { color: var(--vert-fonce); border-bottom: 2px solid var(--vert-fonce); padding-bottom: 2px; }

        /* Calendrier */
        #calendar {
            background: white;
            border-radius: 14px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            border: 1px solid #f1f5f9;
        }

        /* Toolbar FullCalendar */
        .fc .fc-toolbar-title {
            font-size: 1.1rem !important;
            font-weight: 700 !important;
            color: var(--vert-fonce) !important;
        }

        .fc .fc-button {
            background: white !important;
            border: 2px solid #e2e8f0 !important;
            color: #475569 !important;
            border-radius: 10px !important;
            padding: 6px 14px !important;
            font-weight: 600 !important;
            font-size: 0.85rem !important;
            box-shadow: none !important;
            text-transform: none !important;
            transition: all 0.2s ease !important;
        }

        .fc .fc-button:hover {
            background: #f8fafc !important;
            border-color: var(--vert-moyen) !important;
            color: var(--vert-fonce) !important;
        }

        .fc .fc-button-active {
            background: var(--vert-fonce) !important;
            border-color: var(--vert-fonce) !important;
            color: white !important;
        }

        .fc .fc-button-group > .fc-button { border-radius: 0 !important; }
        .fc .fc-button-group > .fc-button:first-child { border-radius: 10px 0 0 10px !important; }
        .fc .fc-button-group > .fc-button:last-child { border-radius: 0 10px 10px 0 !important; }

        /* En-têtes jours */
        .fc .fc-col-header-cell {
            background: #f8fafc !important;
            border-bottom: 2px solid #e2e8f0 !important;
            padding: 10px 0 !important;
        }

        .fc .fc-col-header-cell-cushion {
            color: #475569 !important;
            font-weight: 700 !important;
            font-size: 0.78rem !important;
            text-transform: uppercase !important;
            letter-spacing: 0.6px !important;
        }

        /* Grille */
        .fc td, .fc th { border-color: #f1f5f9 !important; }
        .fc .fc-timegrid-slot { height: 2.5em !important; }
        .fc .fc-timegrid-slot-label { font-size: 0.75rem !important; color: #94a3b8 !important; font-weight: 600 !important; }

        /* Aujourd'hui */
        .fc .fc-day-today { background: rgba(45, 106, 79, 0.04) !important; }

        /* Événements */
        .fc-event {
            background: var(--vert-fonce) !important;
            border: none !important;
            border-radius: 6px !important;
            padding: 3px 8px !important;
            font-size: 0.78rem !important;
            cursor: pointer !important;
            box-shadow: 0 2px 6px rgba(45, 106, 79, 0.2) !important;
            transition: all 0.2s ease !important;
        }
        .fc-event:hover { background: var(--vert-moyen) !important; transform: translateY(-1px); }
        .fc-event-title { font-weight: 600 !important; }
        .fc-event-time { font-size: 0.7rem !important; opacity: 0.85 !important; }

        /* Vue jour */
        .fc-timeGridDay-view .fc-timegrid-slot { height: 3em !important; }
        .fc-timeGridDay-view .fc-event { border-radius: 8px !important; padding: 6px 10px !important; font-size: 0.85rem !important; }

        /* Vue mois */
        .fc-dayGridMonth-view .fc-daygrid-day-number { color: #475569 !important; font-size: 0.85rem !important; padding: 8px !important; font-weight: 600 !important; }

        /* Indicateur heure actuelle */
        .fc .fc-timegrid-now-indicator-line { border-color: #e63946 !important; border-width: 2px !important; }

        /* ========== MODALS ========== */
        #modalRDV, #modalEditRDV, #popupActionsRDV {
            display: none; position: fixed; z-index: 1000;
            left: 0; top: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.4);
        }
        #modalEditRDV { z-index: 1002; }
        #popupActionsRDV { z-index: 1001; }

        .modal-content {
            background: white; max-width: 420px; margin: 6% auto; padding: 28px;
            border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn { from { opacity: 0; transform: scale(0.95) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }

        .modal-content h3 {
            font-size: 1.15rem; font-weight: 700; color: var(--vert-fonce);
            margin: 0 0 20px 0; padding: 0; border: none;
        }

        .search-input {
            width: 100%; padding: 11px 14px; margin: 6px 0;
            border: 2px solid #e2e8f0; border-radius: 10px;
            font-size: 0.95rem; box-sizing: border-box;
            background: #f8fafc; transition: border-color 0.2s;
        }
        .search-input:focus { outline: none; border-color: var(--vert-moyen); background: #fff; }

        label { font-size: 0.85rem; font-weight: 600; color: #475569; margin-top: 12px; display: block; }

        .btn-confirm {
            width: 100%; background: var(--vert-fonce); color: white; padding: 13px;
            border: none; border-radius: 10px; font-weight: 700; margin-top: 20px;
            font-size: 0.95rem; cursor: pointer; transition: all 0.3s ease;
        }
        .btn-confirm:hover { background: #1b4332; transform: translateY(-1px); }

        /* Popup actions */
        .popup-actions-content {
            background: white; max-width: 340px; margin: 12% auto;
            border-radius: 16px; overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            animation: modalIn 0.3s ease;
        }

        .popup-header {
            padding: 18px 22px; border-bottom: 1px solid #f1f5f9;
            background: #f8fafc;
        }
        .popup-header h3 { margin: 0; font-size: 1rem; font-weight: 700; color: var(--vert-fonce); border: none; padding: 0; }

        .popup-close {
            position: absolute; right: 16px; top: 14px; background: none;
            border: none; font-size: 22px; color: #94a3b8; cursor: pointer; padding: 4px;
            transition: color 0.2s;
        }
        .popup-close:hover { color: #333; }

        .popup-actions-list { padding: 8px 0; }

        .popup-action-item {
            display: flex; align-items: center; padding: 13px 22px; cursor: pointer;
            text-decoration: none; color: #1e293b; border: none; background: none;
            width: 100%; font-size: 0.9rem; font-weight: 600; text-align: left;
            transition: all 0.15s ease;
        }
        .popup-action-item:hover { background: #f0fdf4; color: var(--vert-fonce); }
        .popup-action-item.danger:hover { background: #fef2f2; color: #dc2626; }

        .popup-action-icon {
            width: 36px; height: 36px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            margin-right: 14px; font-size: 1rem; background: #f1f5f9;
        }

        .close-modal {
            position: absolute; right: 16px; top: 16px; font-size: 22px;
            color: #94a3b8; cursor: pointer; background: none; border: none; padding: 0;
            transition: color 0.2s;
        }
        .close-modal:hover { color: #333; }

        /* ============================
           RESPONSIVE MOBILE
           ============================ */
        @media (max-width: 768px) {
            .container-large { padding: 12px !important; }

            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            .brand h2 { font-size: 1.1rem; }
            .top-nav { gap: 10px; }
            .top-nav a { font-size: 0.8rem; }

            #calendar { padding: 10px !important; }

            /* FullCalendar mobile */
            .fc .fc-toolbar { flex-direction: column !important; gap: 8px !important; }
            .fc .fc-toolbar-title { font-size: 0.95rem !important; }
            .fc .fc-button { padding: 5px 10px !important; font-size: 0.75rem !important; }

            .fc .fc-col-header-cell-cushion { font-size: 0.65rem !important; }
            .fc .fc-timegrid-slot-label { font-size: 0.65rem !important; }
            .fc-event { font-size: 0.7rem !important; padding: 2px 4px !important; }

            /* Modals */
            .modal-content { width: 95% !important; margin: 3% auto !important; padding: 20px !important; }
            .popup-actions-content { width: 90% !important; margin: 10% auto !important; }

            .search-input { font-size: 0.9rem; }
            .btn-confirm { font-size: 0.9rem; padding: 12px; }

            /* Grille date début/fin en colonne */
            .modal-content div[style*="grid-template-columns: 1fr 1fr"] {
                display: flex !important;
                flex-direction: column !important;
                gap: 8px !important;
            }
        }

        @media (max-width: 480px) {
            .brand h2 { font-size: 1rem; }
            .top-nav a { font-size: 0.72rem; }
            .fc .fc-toolbar-title { font-size: 0.85rem !important; }
        }
    </style>
</head>
<body>

<div class="container-large">

    <!-- TOP BAR (identique aux autres pages) -->
    <div class="top-bar">
        <div class="brand"><h2>📅 Agenda</h2></div>
        <div class="top-nav">
            <a href="<?= htmlspecialchars(route('clients.index')) ?>">🐾 Clients</a>
            <a href="<?= htmlspecialchars(route('facturation.index')) ?>">🧾 Facturation</a>
            <a href="<?= htmlspecialchars(route('declaration.index')) ?>">📊 Déclaration</a>
            <a href="<?= htmlspecialchars(route('settings.index')) ?>">⚙️ Paramètres</a>
            <a href="<?= route('logout') ?>" style="color: #e63946;"><i class="fa-solid fa-right-from-bracket"></i> Déconnexion</a>
        </div>
    </div>

    <div id="calendar"></div>
</div>

<!-- Modal Nouveau RDV -->
<div id="modalRDV">
    <div class="modal-content" style="position:relative;">
        <button class="close-modal" onclick="document.getElementById('modalRDV').style.display='none'">&times;</button>
        <h3>Nouveau rendez-vous</h3>

        <form action="<?= htmlspecialchars(route('appointments.create')) ?>" method="POST" id="formRDV">
            <label>Animal</label>
            <input list="liste_animaux_dl" id="animal_input" class="search-input" placeholder="Rechercher..." required autocomplete="off">
            <input type="hidden" name="id_animal" id="id_animal_hidden">

            <datalist id="liste_animaux_dl">
                <?php foreach($liste_animaux as $a): ?>
                    <?php $info_complet = htmlspecialchars($a['nom_animal']) . " - " . htmlspecialchars($a['prenom_client'] . " " . $a['nom_client']); ?>
                    <option data-id="<?php echo $a['id_animal']; ?>" value="<?php echo $info_complet; ?>">
                <?php endforeach; ?>
            </datalist>

            <label>Prestation</label>
            <input type="text" name="titre" placeholder="Ex: Toilettage complet" required class="search-input">

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                    <label>Début</label>
                    <input type="datetime-local" name="date_debut" id="input_debut" required class="search-input">
                </div>
                <div>
                    <label>Fin</label>
                    <input type="datetime-local" name="date_fin" id="input_fin" required class="search-input">
                </div>
            </div>

            <button type="submit" class="btn-confirm">Confirmer</button>
        </form>
    </div>
</div>

<!-- Popup Actions -->
<div id="popupActionsRDV">
    <div class="popup-actions-content" style="position:relative;">
        <button class="popup-close" onclick="closePopupActions()">&times;</button>
        <div class="popup-header">
            <h3>Actions</h3>
        </div>
        <div class="popup-actions-list">
            <button id="action-modifier" class="popup-action-item">
                <span class="popup-action-icon">✏️</span>
                Modifier
            </button>
            <a href="#" id="action-fiche" class="popup-action-item">
                <span class="popup-action-icon">🐶</span>
                Fiche du chien
            </a>
            <a href="#" id="action-facturer" class="popup-action-item">
                <span class="popup-action-icon">📄</span>
                Facturer
            </a>
            <button id="action-supprimer" class="popup-action-item danger">
                <span class="popup-action-icon">🗑️</span>
                Supprimer
            </button>
        </div>
    </div>
</div>

<!-- Modal Modification -->
<div id="modalEditRDV">
    <div class="modal-content" style="position:relative;">
        <button class="close-modal" onclick="closeEditModal()">&times;</button>
        <h3>Modifier le rendez-vous</h3>
        <p id="edit-animal-name" style="color: #666; margin: 0 0 16px 0; font-size: 0.9rem;"></p>

        <form action="<?= htmlspecialchars(route('appointments.update', ['id' => '__ID__'])) ?>" method="POST" id="formEditRDV">
            <input type="hidden" name="id_rdv" id="edit_id_rdv">

            <label>Prestation</label>
            <input type="text" name="titre" id="edit_titre" required class="search-input">

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                    <label>Début</label>
                    <input type="datetime-local" name="date_debut" id="edit_debut" required class="search-input">
                </div>
                <div>
                    <label>Fin</label>
                    <input type="datetime-local" name="date_fin" id="edit_fin" required class="search-input">
                </div>
            </div>

            <button type="submit" class="btn-confirm">Enregistrer</button>
        </form>
    </div>
</div>

<script>
var selectedRdvId = null;
var selectedAnimalId = null;
var selectedEvent = null;

function closePopupActions() {
    document.getElementById('popupActionsRDV').style.display = 'none';
}

function closeEditModal() {
    document.getElementById('modalEditRDV').style.display = 'none';
}

function openEditModal() {
    closePopupActions();
    document.getElementById('edit_id_rdv').value = selectedRdvId;
    document.getElementById('edit_titre').value = selectedEvent.extendedProps.titre;
    document.getElementById('edit_debut').value = selectedEvent.startStr.slice(0, 16);
    document.getElementById('edit_fin').value = selectedEvent.endStr.slice(0, 16);
    document.getElementById('edit-animal-name').textContent = selectedEvent.extendedProps.nom_animal + ' • ' + selectedEvent.extendedProps.nom_client;

    var form = document.getElementById('formEditRDV');
    var baseUrl = <?= json_encode(route('appointments.update', ['id' => '__ID__'])) ?>;
    form.action = baseUrl.replace('__ID__', selectedRdvId);

    document.getElementById('modalEditRDV').style.display = 'block';
}

function openPopupActions(event) {
    selectedRdvId = event.id;
    selectedAnimalId = event.extendedProps.id_animal;
    selectedEvent = event;

    var trackingUrl = <?= json_encode(route('animals.tracking', ['id' => '__ID__'])) ?>;

    document.getElementById('action-fiche').href = trackingUrl.replace('__ID__', selectedAnimalId) + '#historique-soins';
    document.getElementById('action-facturer').href = trackingUrl.replace('__ID__', selectedAnimalId) + '#nouvelle-visite';

    document.getElementById('popupActionsRDV').style.display = 'block';
}

document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var isMobile = window.innerWidth <= 768;
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: isMobile ? 'timeGridDay' : 'timeGridWeek',
        locale: 'fr',
        slotMinTime: '08:00:00',
        slotMaxTime: '19:00:00',
        selectable: true,
        allDaySlot: false,
        nowIndicator: true,
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        buttonText: {
            today: "Aujourd'hui",
            month: 'Mois',
            week: 'Semaine',
            day: 'Jour'
        },
        events: <?php echo json_encode($events); ?>,

        eventDidMount: function(info) {
            var props = info.event.extendedProps;
            info.el.setAttribute('title', props.nom_animal + ' - ' + props.titre + '\n' + props.nom_client);
        },

        select: function(info) {
            document.getElementById('modalRDV').style.display = 'block';
            document.getElementById('input_debut').value = info.startStr.slice(0, 16);
            document.getElementById('input_fin').value = info.endStr.slice(0, 16);
            document.getElementById('animal_input').value = "";
            document.getElementById('id_animal_hidden').value = "";
        },

        eventClick: function(info) {
            openPopupActions(info.event);
        }
    });

    calendar.render();

    // Fermer en cliquant à l'extérieur
    ['popupActionsRDV', 'modalRDV', 'modalEditRDV'].forEach(function(id) {
        document.getElementById(id).addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });

    document.getElementById('action-modifier').addEventListener('click', openEditModal);

    document.getElementById('action-supprimer').addEventListener('click', function() {
        if (selectedRdvId && confirm("Supprimer ce rendez-vous ?")) {
            var templateUrl = <?= json_encode(route('appointments.delete', ['id' => '__ID__'])) ?>;
            fetch(templateUrl.replace('__ID__', selectedRdvId), { method: 'POST' })
                .then(function() { window.location.reload(); });
        }
    });

    document.getElementById('animal_input').addEventListener('input', function(e) {
        var options = document.getElementById('liste_animaux_dl').options;
        var hiddenInput = document.getElementById('id_animal_hidden');
        for (var i = 0; i < options.length; i++) {
            if (options[i].value === e.target.value) {
                hiddenInput.value = options[i].getAttribute('data-id');
                return;
            }
        }
        hiddenInput.value = "";
    });

    document.getElementById('formRDV').addEventListener('submit', function(e) {
        if (!document.getElementById('id_animal_hidden').value) {
            e.preventDefault();
            alert("Veuillez sélectionner un animal dans la liste.");
        }
    });
});
</script>

</body>
</html>
