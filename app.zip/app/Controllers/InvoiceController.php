<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;
use Atgp\FacturX\Writer;

class InvoiceController extends Controller
{
    public function generate($id = 0)
    {
        $this->requireLogin();

        $id_prestation = (int)$id;
        if ($id_prestation <= 0) {
            redirect('clients.index');
            exit;
        }

        $pdo = Database::getConnection();

        // Vérifier s'il y a un groupe multi-animaux en session
        $groupeIds = [];
        if (!empty($_SESSION['facture_groupe']) && is_array($_SESSION['facture_groupe'])) {
            $groupeIds = $_SESSION['facture_groupe'];
            unset($_SESSION['facture_groupe']);
        } else {
            $groupeIds = [$id_prestation];
        }

        // Récupérer toutes les prestations du groupe
        $placeholders = implode(',', array_fill(0, count($groupeIds), '?'));
        $query = $pdo->prepare("
            SELECT p.*, a.id_animal, a.nom_animal, a.espece, prop.nom, prop.prenom, prop.telephone, prop.id_proprietaire
            FROM Prestations p
            JOIN Animaux a ON p.id_animal = a.id_animal
            JOIN Proprietaires prop ON a.id_proprietaire = prop.id_proprietaire
            WHERE p.id_prestation IN ($placeholders)
            ORDER BY p.id_prestation ASC
        ");
        $query->execute($groupeIds);
        $allPrestations = $query->fetchAll(PDO::FETCH_ASSOC);

        if (empty($allPrestations)) die("Prestation introuvable.");

        // La première prestation sert de référence (client, date)
        $data = $allPrestations[0];

        // Calculer le prix total (somme de toutes les prestations du groupe)
        $prixTotal = 0;
        foreach ($allPrestations as $p) {
            $prixTotal += (float)$p['prix'];
        }
        $data['prix_total'] = $prixTotal;
        $data['prestations'] = $allPrestations;
        $data['is_multi'] = count($allPrestations) > 1;

        // Lire code.env à la racine
        $apiKey = null;
        $apiUrl = "https://api.n2f.com/v1/expenses/upload";
        $envPath = __DIR__ . '/../../code.env';

        if (file_exists($envPath)) {
            $content = file_get_contents($envPath);
            if (preg_match('/N2F_API_KEY\s*=\s*([^\s#]+)/', $content, $m)) $apiKey = trim($m[1], "\"' ");
            if (preg_match('/N2F_API_URL\s*=\s*([^\s#]+)/', $content, $m)) $apiUrl = trim($m[1], "\"' ");
        }
        if (!$apiKey) die("Erreur : API Key manquante.");

        // PDF
        $options = new Options();
        $options->set('isRemoteEnabled', true);
        $options->set('defaultFont', 'DejaVu Sans');
        $dompdf = new Dompdf($options);

        ob_start();
        include __DIR__ . '/../Views/facture_view.php';
        $html = ob_get_clean();

        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $pdfOutput = $dompdf->output();

        // XML Factur-X
        $dateSoin  = date('Ymd', strtotime($data['date_soin']));
        $idFacture = date('Y') . '-' . $data['id_prestation'];
        $prix      = number_format($prixTotal, 2, '.', '');

        $xml = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
  <rsm:ExchangedDocumentContext>
    <ram:GuidelineSpecifiedDocumentContextParameter>
      <ram:ID>urn:factur-x.eu:1p0:minimum</ram:ID>
    </ram:GuidelineSpecifiedDocumentContextParameter>
  </rsm:ExchangedDocumentContext>
  <rsm:ExchangedDocument>
    <ram:ID>$idFacture</ram:ID>
    <ram:TypeCode>380</ram:TypeCode>
    <ram:IssueDateTime>
      <udt:DateTimeString format="102">$dateSoin</udt:DateTimeString>
    </ram:IssueDateTime>
  </rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    <ram:ApplicableHeaderTradeAgreement>
      <ram:SellerTradeParty>
        <ram:Name>SweetyDog41</ram:Name>
        <ram:SpecifiedLegalOrganization>
          <ram:ID schemeID="0002">12345678901234</ram:ID>
        </ram:SpecifiedLegalOrganization>
        <ram:PostalTradeAddress>
          <ram:CountryID>FR</ram:CountryID>
        </ram:PostalTradeAddress>
      </ram:SellerTradeParty>
      <ram:BuyerTradeParty>
        <ram:Name>{$data['prenom']} {$data['nom']}</ram:Name>
      </ram:BuyerTradeParty>
    </ram:ApplicableHeaderTradeAgreement>
    <ram:ApplicableHeaderTradeDelivery/>
    <ram:ApplicableHeaderTradeSettlement>
      <ram:InvoiceCurrencyCode>EUR</ram:InvoiceCurrencyCode>
      <ram:SpecifiedTradeSettlementHeaderMonetarySummation>
        <ram:TaxBasisTotalAmount currencyID="EUR">$prix</ram:TaxBasisTotalAmount>
        <ram:GrandTotalAmount currencyID="EUR">$prix</ram:GrandTotalAmount>
        <ram:DuePayableAmount currencyID="EUR">$prix</ram:DuePayableAmount>
      </ram:SpecifiedTradeSettlementHeaderMonetarySummation>
    </ram:ApplicableHeaderTradeSettlement>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>
XML;

        $writer = new Writer();
        $factureHybride = $writer->generate($pdfOutput, $xml);

        $nomFichier = "Facture_SweetyDog_" . $idFacture . ".pdf";
        $dir = __DIR__ . '/../../factures/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $chemin = $dir . $nomFichier;

        file_put_contents($chemin, $factureHybride);

        // Créer une copie du PDF pour chaque prestation du groupe
        // Pour que chaque animal puisse accéder à la facture via son propre ID
        if (count($groupeIds) > 1) {
            foreach ($groupeIds as $gId) {
                if ((int)$gId === $id_prestation) continue; // Déjà sauvegardé
                $nomCopie = "Facture_SweetyDog_" . date('Y') . "-" . $gId . ".pdf";
                $cheminCopie = $dir . $nomCopie;
                copy($chemin, $cheminCopie);
            }
        }

        // Upload N2F
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ['file' => new CURLFile($chemin, 'application/pdf', $nomFichier)]);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: ApiKey $apiKey"]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);

        // Rediriger selon l'origine de l'appel
        if (!empty($_GET['from']) && $_GET['from'] === 'facturation') {
            $id_proprio = (int)($data['id_proprietaire'] ?? 0);
            redirect('facturation.index', [], ['client' => $id_proprio, 'success' => 1]);
        } else {
            redirect('animals.tracking', ['id' => $data['id_animal']], ['success' => 1]);
        }
    }

    /**
     * Télécharge une facture de manière sécurisée
     * Vérifie l'authentification avant de servir le PDF
     */
    public function download($id = 0)
    {
        // 🔒 SÉCURITÉ : Vérifier que l'utilisateur est connecté
        $this->requireLogin();

        $id_prestation = (int)$id;
        if ($id_prestation <= 0) {
            http_response_code(404);
            die("Facture introuvable");
        }

        // Vérifier que la prestation existe et récupérer la date
        $pdo = Database::getConnection();
        $query = $pdo->prepare("SELECT date_soin FROM Prestations WHERE id_prestation = ?");
        $query->execute([$id_prestation]);
        $prestation = $query->fetch(PDO::FETCH_ASSOC);

        if (!$prestation) {
            http_response_code(404);
            die("Prestation introuvable");
        }

        // Construire le nom du fichier
        $annee = date('Y', strtotime($prestation['date_soin']));
        $nomFichier = "Facture_SweetyDog_{$annee}-{$id_prestation}.pdf";
        $cheminFacture = __DIR__ . '/../../factures/' . $nomFichier;

        // Vérifier que le fichier existe
        if (!file_exists($cheminFacture)) {
            http_response_code(404);
            die("Facture PDF non trouvée. Générez-la d'abord.");
        }

        // 🔒 SÉCURITÉ SUPPLÉMENTAIRE (optionnel) : 
        // Vérifier que l'utilisateur connecté a le droit d'accéder à cette facture
        // Par exemple, vérifier qu'il s'agit bien de son client
        // À implémenter selon vos besoins

        // Servir le PDF de manière sécurisée
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $nomFichier . '"');
        header('Content-Length: ' . filesize($cheminFacture));
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');

        // Lire et envoyer le fichier
        readfile($cheminFacture);
        exit;
    }
}
