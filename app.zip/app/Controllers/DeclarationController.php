<?php

class DeclarationController extends Controller
{
    public function index()
    {
        $this->requireLogin();

        require_once __DIR__ . '/../../config/db.php';

        // Mois et année sélectionnés (par défaut : mois courant)
        $mois  = isset($_GET['mois'])  ? (int)$_GET['mois']  : (int)date('n');
        $annee = isset($_GET['annee']) ? (int)$_GET['annee'] : (int)date('Y');

        // Borner les valeurs
        if ($mois < 1 || $mois > 12) $mois = (int)date('n');
        if ($annee < 2020 || $annee > 2040) $annee = (int)date('Y');

        // Récupérer les données
        $caParType     = Declaration::getCAParType($mois, $annee);
        $caTotal       = Declaration::getCATotalMois($mois, $annee);
        $nbPrestations = Declaration::getNbPrestationsMois($mois, $annee);

        $this->view('declaration_view', compact(
            'mois', 'annee', 'caParType', 'caTotal', 'nbPrestations'
        ));
    }
}
